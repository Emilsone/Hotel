# team-transavania
Check out at https://taiwrash.github.io/team-transavania


#GETTING STARTED


-fork the repo


-clone forked repo


-add your project/task to the clone file


-push back to github



make PR (pull request)
