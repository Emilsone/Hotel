# team-transavania
Check it out at https://taiwrash.github.io/team-transavania

### GETTING STARTED

- Fork the repo
- Clone the forked repo
- Make your edits in your local machine
- Add your edits to the cloned files
- Push your changes to the cloned repository
- Make a PR (pull request)
- Viola! You are done.
